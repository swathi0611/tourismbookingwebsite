<?php
$server="localhost";
$user="root";
$pass="";
$db="bookings";
$conn=mysqli_connect($server,$user,$pass,$db);